# 式样说明

## 配色

| | 余白 | 晴日 |
| --- | --- | --- |
| 主色 | 棕色 `#8A6248` | 蓝色 `#399BE8` |
| 底色 / 辅色 | 米白 `#F6F3ED` | 珊瑚 `#F26B5B`、黄色 `#F4C84A` |
| 配置位置 | `build.py` 的 A 主题 | `themes.json` 的 `sunny-day` |
| Token ID | `A` | `SUNNY-DAY` |
| 页面 | `a-yohaku.html` | `theme-sunny-day.html` |

两套样式使用相同组件。每套都有浅色、深色，以及对应的增强对比度模式。深色和扩展组件放在同名的 `-ext.html` 页面里。其余配色可从 `index.html` 进入。

## 组件

- 基础：按钮、输入框、开关、列表、日历和整屏日程示例。
- 扩展：Sheet、Alert、空状态、离线提示、引导页和图表。
- 时间选择：仅小时、小时＋分钟两种滚轮。使用 24 小时制，默认每次调整 1 分钟；两列一起确认或取消，分钟首尾循环不改变小时。
- Widget：小号和中号桌面小组件，以及圆形、矩形、行内锁屏布局。
- 其他：169 枚线性图标、设备尺寸样张和可调容器演示。

页面上方的画板用来展示外观。要试操作，请往下找到「可操作组件」或时间滚轮区域。搜索、表单和加载状态都使用本地示例数据；刷新后恢复初始状态。日文文案用于排版展示。

## 取用颜色

从 `design-tokens.json` 的 `themes.<ID>` 中选择 `light`、`dark`、`light_hc` 或 `dark_hc`：

| 用途 | 字段 |
| --- | --- |
| 主按钮底色 / 按钮文字 | `accent` / `on_accent` |
| 普通背景上的文字操作 | `accent_text` |
| 强调图标与必要边界 | `accent_ui` / `control_border` |

不要把较浅的按钮底色直接用作文字颜色。分类颜色和错误、成功、警告颜色分开使用；状态还应配文字或图标。

字号、间距和控件形状见 `standards.html`。文字按钮使用胶囊形，图标按钮使用圆形。实际 iOS 项目应读取系统字号和安全区，不能照搬 HTML 中的尺寸常量。

## 接入 App

`native/` 提供颜色适配器和一个 React Native 动作示例。SwiftUI 组件、WidgetKit 扩展、联网和持久化功能需要在自己的项目中实现。

修改样式时，先读 [Skill](../skill/SKILL.md)，再修改相应生成器或主题配置。运行方法见 [Python 文件与版本](python-support.md)，截图更新方法见 [previews/README.md](previews/README.md)。

## 弹层与表单

日期／时间选择、滚动隔离、键盘避让和数字对齐见[交互说明](interaction-standard.md)与 `standards.html#picker-presentation`。时间示例仍为展开内容；完整模态和原生性能由接入项目验证。
